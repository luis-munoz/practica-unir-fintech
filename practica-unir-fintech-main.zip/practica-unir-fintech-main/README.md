# practica-unir-fintech
Repositorio requerido para la actividad 1
